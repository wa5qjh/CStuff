/****************************************************************************
** Meta object code from reading C++ file 'dialogwarden.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.5.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "dialogwarden.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'dialogwarden.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.5.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_dialogWarden_t {
    QByteArrayData data[59];
    char stringdata0[1005];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_dialogWarden_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_dialogWarden_t qt_meta_stringdata_dialogWarden = {
    {
QT_MOC_LITERAL(0, 0, 12), // "dialogWarden"
QT_MOC_LITERAL(1, 13, 18), // "slotSingleInstance"
QT_MOC_LITERAL(2, 32, 0), // ""
QT_MOC_LITERAL(3, 33, 9), // "helpAbout"
QT_MOC_LITERAL(4, 43, 12), // "refreshJails"
QT_MOC_LITERAL(5, 56, 10), // "readConfig"
QT_MOC_LITERAL(6, 67, 14), // "slotOpenConfig"
QT_MOC_LITERAL(7, 82, 8), // "slotExit"
QT_MOC_LITERAL(8, 91, 19), // "slotCheckJailStatus"
QT_MOC_LITERAL(9, 111, 21), // "slotMonitorJailStatus"
QT_MOC_LITERAL(10, 133, 21), // "slotCheckStatusReturn"
QT_MOC_LITERAL(11, 155, 20), // "slotCheckJailDetails"
QT_MOC_LITERAL(12, 176, 22), // "slotMonitorJailDetails"
QT_MOC_LITERAL(13, 199, 22), // "slotCheckDetailsReturn"
QT_MOC_LITERAL(14, 222, 20), // "slotJailRightClicked"
QT_MOC_LITERAL(15, 243, 12), // "slotStopJail"
QT_MOC_LITERAL(16, 256, 13), // "slotStartJail"
QT_MOC_LITERAL(17, 270, 14), // "slotExportJail"
QT_MOC_LITERAL(18, 285, 16), // "slotListJailPkgs"
QT_MOC_LITERAL(19, 302, 14), // "slotDeleteJail"
QT_MOC_LITERAL(20, 317, 19), // "slotFinishedWorking"
QT_MOC_LITERAL(21, 337, 18), // "slotFinishedOutput"
QT_MOC_LITERAL(22, 356, 18), // "slotReadPkgsOutput"
QT_MOC_LITERAL(23, 375, 18), // "slotClickedNewJail"
QT_MOC_LITERAL(24, 394, 17), // "slotCreateNewJail"
QT_MOC_LITERAL(25, 412, 20), // "slotReadCreateOutput"
QT_MOC_LITERAL(26, 433, 22), // "slotFinishedJailCreate"
QT_MOC_LITERAL(27, 456, 21), // "slotReadUserAddOutput"
QT_MOC_LITERAL(28, 478, 19), // "slotFinishedUserAdd"
QT_MOC_LITERAL(29, 498, 21), // "slotImportJailClicked"
QT_MOC_LITERAL(30, 520, 20), // "slotReadImportOutput"
QT_MOC_LITERAL(31, 541, 22), // "slotFinishedJailImport"
QT_MOC_LITERAL(32, 564, 26), // "slotToggleAutostartClicked"
QT_MOC_LITERAL(33, 591, 20), // "slotImportConfigDone"
QT_MOC_LITERAL(34, 612, 8), // "JailName"
QT_MOC_LITERAL(35, 621, 2), // "IP"
QT_MOC_LITERAL(36, 624, 4), // "Host"
QT_MOC_LITERAL(37, 629, 22), // "slotCurrentJailChanged"
QT_MOC_LITERAL(38, 652, 12), // "slotTerminal"
QT_MOC_LITERAL(39, 665, 13), // "slotUserAdmin"
QT_MOC_LITERAL(40, 679, 14), // "slotPushEditIP"
QT_MOC_LITERAL(41, 694, 15), // "slotPushPackage"
QT_MOC_LITERAL(42, 710, 10), // "slotUpdate"
QT_MOC_LITERAL(43, 721, 25), // "slotShowDialogCloseButton"
QT_MOC_LITERAL(44, 747, 14), // "slotServiceGUI"
QT_MOC_LITERAL(45, 762, 20), // "slotReadExportOutput"
QT_MOC_LITERAL(46, 783, 18), // "slotFinishedExport"
QT_MOC_LITERAL(47, 802, 19), // "slotCheckForUpdates"
QT_MOC_LITERAL(48, 822, 21), // "slotCheckUpdateReturn"
QT_MOC_LITERAL(49, 844, 12), // "slotCheckNic"
QT_MOC_LITERAL(50, 857, 21), // "slotSnapSliderChanged"
QT_MOC_LITERAL(51, 879, 6), // "newVal"
QT_MOC_LITERAL(52, 886, 17), // "slotLoadSnapshots"
QT_MOC_LITERAL(53, 904, 14), // "slotCreateSnap"
QT_MOC_LITERAL(54, 919, 15), // "slotRestoreSnap"
QT_MOC_LITERAL(55, 935, 14), // "slotRemoveSnap"
QT_MOC_LITERAL(56, 950, 13), // "slotMakeClone"
QT_MOC_LITERAL(57, 964, 23), // "slotCronSnapshotChanged"
QT_MOC_LITERAL(58, 988, 16) // "slotTemplateOpen"

    },
    "dialogWarden\0slotSingleInstance\0\0"
    "helpAbout\0refreshJails\0readConfig\0"
    "slotOpenConfig\0slotExit\0slotCheckJailStatus\0"
    "slotMonitorJailStatus\0slotCheckStatusReturn\0"
    "slotCheckJailDetails\0slotMonitorJailDetails\0"
    "slotCheckDetailsReturn\0slotJailRightClicked\0"
    "slotStopJail\0slotStartJail\0slotExportJail\0"
    "slotListJailPkgs\0slotDeleteJail\0"
    "slotFinishedWorking\0slotFinishedOutput\0"
    "slotReadPkgsOutput\0slotClickedNewJail\0"
    "slotCreateNewJail\0slotReadCreateOutput\0"
    "slotFinishedJailCreate\0slotReadUserAddOutput\0"
    "slotFinishedUserAdd\0slotImportJailClicked\0"
    "slotReadImportOutput\0slotFinishedJailImport\0"
    "slotToggleAutostartClicked\0"
    "slotImportConfigDone\0JailName\0IP\0Host\0"
    "slotCurrentJailChanged\0slotTerminal\0"
    "slotUserAdmin\0slotPushEditIP\0"
    "slotPushPackage\0slotUpdate\0"
    "slotShowDialogCloseButton\0slotServiceGUI\0"
    "slotReadExportOutput\0slotFinishedExport\0"
    "slotCheckForUpdates\0slotCheckUpdateReturn\0"
    "slotCheckNic\0slotSnapSliderChanged\0"
    "newVal\0slotLoadSnapshots\0slotCreateSnap\0"
    "slotRestoreSnap\0slotRemoveSnap\0"
    "slotMakeClone\0slotCronSnapshotChanged\0"
    "slotTemplateOpen"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_dialogWarden[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      53,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,  279,    2, 0x0a /* Public */,
       3,    0,  280,    2, 0x08 /* Private */,
       4,    0,  281,    2, 0x08 /* Private */,
       5,    0,  282,    2, 0x08 /* Private */,
       6,    0,  283,    2, 0x08 /* Private */,
       7,    0,  284,    2, 0x08 /* Private */,
       8,    0,  285,    2, 0x08 /* Private */,
       9,    0,  286,    2, 0x08 /* Private */,
      10,    0,  287,    2, 0x08 /* Private */,
      11,    0,  288,    2, 0x08 /* Private */,
      12,    0,  289,    2, 0x08 /* Private */,
      13,    0,  290,    2, 0x08 /* Private */,
      14,    0,  291,    2, 0x08 /* Private */,
      15,    0,  292,    2, 0x08 /* Private */,
      16,    0,  293,    2, 0x08 /* Private */,
      17,    0,  294,    2, 0x08 /* Private */,
      18,    0,  295,    2, 0x08 /* Private */,
      19,    0,  296,    2, 0x08 /* Private */,
      20,    0,  297,    2, 0x08 /* Private */,
      21,    0,  298,    2, 0x08 /* Private */,
      22,    0,  299,    2, 0x08 /* Private */,
      23,    0,  300,    2, 0x08 /* Private */,
      24,   12,  301,    2, 0x08 /* Private */,
      25,    0,  326,    2, 0x08 /* Private */,
      26,    0,  327,    2, 0x08 /* Private */,
      27,    0,  328,    2, 0x08 /* Private */,
      28,    0,  329,    2, 0x08 /* Private */,
      29,    0,  330,    2, 0x08 /* Private */,
      30,    0,  331,    2, 0x08 /* Private */,
      31,    0,  332,    2, 0x08 /* Private */,
      32,    0,  333,    2, 0x08 /* Private */,
      33,    3,  334,    2, 0x08 /* Private */,
      37,    0,  341,    2, 0x08 /* Private */,
      38,    0,  342,    2, 0x08 /* Private */,
      39,    0,  343,    2, 0x08 /* Private */,
      40,    0,  344,    2, 0x08 /* Private */,
      41,    0,  345,    2, 0x08 /* Private */,
      42,    0,  346,    2, 0x08 /* Private */,
      43,    0,  347,    2, 0x08 /* Private */,
      44,    0,  348,    2, 0x08 /* Private */,
      45,    0,  349,    2, 0x08 /* Private */,
      46,    0,  350,    2, 0x08 /* Private */,
      47,    0,  351,    2, 0x08 /* Private */,
      48,    0,  352,    2, 0x08 /* Private */,
      49,    0,  353,    2, 0x08 /* Private */,
      50,    1,  354,    2, 0x08 /* Private */,
      52,    0,  357,    2, 0x08 /* Private */,
      53,    0,  358,    2, 0x08 /* Private */,
      54,    0,  359,    2, 0x08 /* Private */,
      55,    0,  360,    2, 0x08 /* Private */,
      56,    0,  361,    2, 0x08 /* Private */,
      57,    0,  362,    2, 0x08 /* Private */,
      58,    0,  363,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString, QMetaType::QString, QMetaType::QString, QMetaType::Bool, QMetaType::Bool, QMetaType::QString, QMetaType::Bool, QMetaType::Bool, QMetaType::Bool, QMetaType::Bool, QMetaType::QString, QMetaType::QString,    2,    2,    2,    2,    2,    2,    2,    2,    2,    2,    2,    2,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString, QMetaType::QString, QMetaType::QString,   34,   35,   36,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   51,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void dialogWarden::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        dialogWarden *_t = static_cast<dialogWarden *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->slotSingleInstance(); break;
        case 1: _t->helpAbout(); break;
        case 2: _t->refreshJails(); break;
        case 3: _t->readConfig(); break;
        case 4: _t->slotOpenConfig(); break;
        case 5: _t->slotExit(); break;
        case 6: _t->slotCheckJailStatus(); break;
        case 7: _t->slotMonitorJailStatus(); break;
        case 8: _t->slotCheckStatusReturn(); break;
        case 9: _t->slotCheckJailDetails(); break;
        case 10: _t->slotMonitorJailDetails(); break;
        case 11: _t->slotCheckDetailsReturn(); break;
        case 12: _t->slotJailRightClicked(); break;
        case 13: _t->slotStopJail(); break;
        case 14: _t->slotStartJail(); break;
        case 15: _t->slotExportJail(); break;
        case 16: _t->slotListJailPkgs(); break;
        case 17: _t->slotDeleteJail(); break;
        case 18: _t->slotFinishedWorking(); break;
        case 19: _t->slotFinishedOutput(); break;
        case 20: _t->slotReadPkgsOutput(); break;
        case 21: _t->slotClickedNewJail(); break;
        case 22: _t->slotCreateNewJail((*reinterpret_cast< const QString(*)>(_a[1])),(*reinterpret_cast< const QString(*)>(_a[2])),(*reinterpret_cast< const QString(*)>(_a[3])),(*reinterpret_cast< bool(*)>(_a[4])),(*reinterpret_cast< bool(*)>(_a[5])),(*reinterpret_cast< const QString(*)>(_a[6])),(*reinterpret_cast< bool(*)>(_a[7])),(*reinterpret_cast< bool(*)>(_a[8])),(*reinterpret_cast< bool(*)>(_a[9])),(*reinterpret_cast< bool(*)>(_a[10])),(*reinterpret_cast< const QString(*)>(_a[11])),(*reinterpret_cast< const QString(*)>(_a[12]))); break;
        case 23: _t->slotReadCreateOutput(); break;
        case 24: _t->slotFinishedJailCreate(); break;
        case 25: _t->slotReadUserAddOutput(); break;
        case 26: _t->slotFinishedUserAdd(); break;
        case 27: _t->slotImportJailClicked(); break;
        case 28: _t->slotReadImportOutput(); break;
        case 29: _t->slotFinishedJailImport(); break;
        case 30: _t->slotToggleAutostartClicked(); break;
        case 31: _t->slotImportConfigDone((*reinterpret_cast< const QString(*)>(_a[1])),(*reinterpret_cast< const QString(*)>(_a[2])),(*reinterpret_cast< const QString(*)>(_a[3]))); break;
        case 32: _t->slotCurrentJailChanged(); break;
        case 33: _t->slotTerminal(); break;
        case 34: _t->slotUserAdmin(); break;
        case 35: _t->slotPushEditIP(); break;
        case 36: _t->slotPushPackage(); break;
        case 37: _t->slotUpdate(); break;
        case 38: _t->slotShowDialogCloseButton(); break;
        case 39: _t->slotServiceGUI(); break;
        case 40: _t->slotReadExportOutput(); break;
        case 41: _t->slotFinishedExport(); break;
        case 42: _t->slotCheckForUpdates(); break;
        case 43: _t->slotCheckUpdateReturn(); break;
        case 44: _t->slotCheckNic(); break;
        case 45: _t->slotSnapSliderChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 46: _t->slotLoadSnapshots(); break;
        case 47: _t->slotCreateSnap(); break;
        case 48: _t->slotRestoreSnap(); break;
        case 49: _t->slotRemoveSnap(); break;
        case 50: _t->slotMakeClone(); break;
        case 51: _t->slotCronSnapshotChanged(); break;
        case 52: _t->slotTemplateOpen(); break;
        default: ;
        }
    }
}

const QMetaObject dialogWarden::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_dialogWarden.data,
      qt_meta_data_dialogWarden,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *dialogWarden::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *dialogWarden::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_dialogWarden.stringdata0))
        return static_cast<void*>(const_cast< dialogWarden*>(this));
    return QMainWindow::qt_metacast(_clname);
}

int dialogWarden::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 53)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 53;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 53)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 53;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
