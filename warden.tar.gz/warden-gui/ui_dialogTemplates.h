/********************************************************************************
** Form generated from reading UI file 'dialogTemplates.ui'
**
** Created by: Qt User Interface Compiler version 5.5.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DIALOGTEMPLATES_H
#define UI_DIALOGTEMPLATES_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QTreeWidget>

QT_BEGIN_NAMESPACE

class Ui_dialogTemplates
{
public:
    QGridLayout *gridLayout;
    QTreeWidget *listTemps;
    QHBoxLayout *horizontalLayout;
    QSpacerItem *horizontalSpacer;
    QPushButton *pushAdd;
    QPushButton *pushRemove;
    QSpacerItem *horizontalSpacer_2;
    QPushButton *pushClose;

    void setupUi(QDialog *dialogTemplates)
    {
        if (dialogTemplates->objectName().isEmpty())
            dialogTemplates->setObjectName(QStringLiteral("dialogTemplates"));
        dialogTemplates->resize(424, 273);
        gridLayout = new QGridLayout(dialogTemplates);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        listTemps = new QTreeWidget(dialogTemplates);
        QTreeWidgetItem *__qtreewidgetitem = new QTreeWidgetItem();
        __qtreewidgetitem->setText(2, QStringLiteral("Arch"));
        __qtreewidgetitem->setText(1, QStringLiteral("Version"));
        __qtreewidgetitem->setText(0, QStringLiteral("Nickname"));
        listTemps->setHeaderItem(__qtreewidgetitem);
        listTemps->setObjectName(QStringLiteral("listTemps"));
        QSizePolicy sizePolicy(QSizePolicy::Expanding, QSizePolicy::MinimumExpanding);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(listTemps->sizePolicy().hasHeightForWidth());
        listTemps->setSizePolicy(sizePolicy);
        listTemps->setIndentation(0);
        listTemps->setUniformRowHeights(false);
        listTemps->setItemsExpandable(true);
        listTemps->setSortingEnabled(true);
        listTemps->setAllColumnsShowFocus(true);
        listTemps->setHeaderHidden(false);
        listTemps->header()->setVisible(true);
        listTemps->header()->setCascadingSectionResizes(false);
        listTemps->header()->setDefaultSectionSize(90);
        listTemps->header()->setMinimumSectionSize(90);
        listTemps->header()->setProperty("showSortIndicator", QVariant(true));
        listTemps->header()->setStretchLastSection(true);

        gridLayout->addWidget(listTemps, 0, 0, 1, 2);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        horizontalSpacer = new QSpacerItem(298, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer);

        pushAdd = new QPushButton(dialogTemplates);
        pushAdd->setObjectName(QStringLiteral("pushAdd"));
        pushAdd->setMinimumSize(QSize(32, 32));
        pushAdd->setMaximumSize(QSize(32, 32));
        QIcon icon;
        icon.addFile(QStringLiteral(":/edit_add.png"), QSize(), QIcon::Normal, QIcon::Off);
        pushAdd->setIcon(icon);
        pushAdd->setIconSize(QSize(20, 20));

        horizontalLayout->addWidget(pushAdd);

        pushRemove = new QPushButton(dialogTemplates);
        pushRemove->setObjectName(QStringLiteral("pushRemove"));
        pushRemove->setMinimumSize(QSize(32, 32));
        pushRemove->setMaximumSize(QSize(32, 32));
        QIcon icon1;
        icon1.addFile(QStringLiteral(":/edit_remove.png"), QSize(), QIcon::Normal, QIcon::Off);
        pushRemove->setIcon(icon1);
        pushRemove->setIconSize(QSize(20, 20));

        horizontalLayout->addWidget(pushRemove);


        gridLayout->addLayout(horizontalLayout, 1, 0, 1, 2);

        horizontalSpacer_2 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout->addItem(horizontalSpacer_2, 2, 0, 1, 1);

        pushClose = new QPushButton(dialogTemplates);
        pushClose->setObjectName(QStringLiteral("pushClose"));

        gridLayout->addWidget(pushClose, 2, 1, 1, 1);


        retranslateUi(dialogTemplates);

        QMetaObject::connectSlotsByName(dialogTemplates);
    } // setupUi

    void retranslateUi(QDialog *dialogTemplates)
    {
        dialogTemplates->setWindowTitle(QApplication::translate("dialogTemplates", "Jail Templates", 0));
#ifndef QT_NO_TOOLTIP
        pushAdd->setToolTip(QApplication::translate("dialogTemplates", "Add a new Jail", 0));
#endif // QT_NO_TOOLTIP
        pushAdd->setText(QString());
#ifndef QT_NO_TOOLTIP
        pushRemove->setToolTip(QApplication::translate("dialogTemplates", "Remove the selected Jail", 0));
#endif // QT_NO_TOOLTIP
        pushRemove->setText(QString());
        pushClose->setText(QApplication::translate("dialogTemplates", "&Close", 0));
    } // retranslateUi

};

namespace Ui {
    class dialogTemplates: public Ui_dialogTemplates {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DIALOGTEMPLATES_H
