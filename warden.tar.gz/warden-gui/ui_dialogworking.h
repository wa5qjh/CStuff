/********************************************************************************
** Form generated from reading UI file 'dialogworking.ui'
**
** Created by: Qt User Interface Compiler version 5.5.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DIALOGWORKING_H
#define UI_DIALOGWORKING_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QProgressBar>
#include <QtWidgets/QSpacerItem>

QT_BEGIN_NAMESPACE

class Ui_dialogWorking
{
public:
    QGridLayout *gridLayout;
    QGridLayout *gridLayout1;
    QSpacerItem *spacer1_2;
    QSpacerItem *spacer1;
    QLabel *textText;
    QProgressBar *progressBarWorking;

    void setupUi(QDialog *dialogWorking)
    {
        if (dialogWorking->objectName().isEmpty())
            dialogWorking->setObjectName(QStringLiteral("dialogWorking"));
        dialogWorking->resize(307, 94);
        QIcon icon;
        icon.addFile(QStringLiteral(":/warden.png"), QSize(), QIcon::Normal, QIcon::Off);
        dialogWorking->setWindowIcon(icon);
        gridLayout = new QGridLayout(dialogWorking);
        gridLayout->setSpacing(6);
        gridLayout->setContentsMargins(11, 11, 11, 11);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        gridLayout1 = new QGridLayout();
        gridLayout1->setSpacing(6);
        gridLayout1->setObjectName(QStringLiteral("gridLayout1"));
        spacer1_2 = new QSpacerItem(20, 80, QSizePolicy::Fixed, QSizePolicy::Minimum);

        gridLayout1->addItem(spacer1_2, 0, 2, 3, 1);

        spacer1 = new QSpacerItem(20, 80, QSizePolicy::Fixed, QSizePolicy::Minimum);

        gridLayout1->addItem(spacer1, 0, 0, 3, 1);

        textText = new QLabel(dialogWorking);
        textText->setObjectName(QStringLiteral("textText"));
        textText->setAlignment(Qt::AlignCenter);
        textText->setWordWrap(false);

        gridLayout1->addWidget(textText, 0, 1, 1, 1);

        progressBarWorking = new QProgressBar(dialogWorking);
        progressBarWorking->setObjectName(QStringLiteral("progressBarWorking"));
        progressBarWorking->setValue(24);

        gridLayout1->addWidget(progressBarWorking, 1, 1, 1, 1);


        gridLayout->addLayout(gridLayout1, 0, 0, 1, 1);


        retranslateUi(dialogWorking);

        QMetaObject::connectSlotsByName(dialogWorking);
    } // setupUi

    void retranslateUi(QDialog *dialogWorking)
    {
        dialogWorking->setWindowTitle(QApplication::translate("dialogWorking", "Working", 0));
        textText->setText(QApplication::translate("dialogWorking", "Working", 0));
    } // retranslateUi

};

namespace Ui {
    class dialogWorking: public Ui_dialogWorking {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DIALOGWORKING_H
